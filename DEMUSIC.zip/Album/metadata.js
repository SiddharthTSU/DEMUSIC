let fs = require("fs");
let axios = require("axios");

let songs = ["Atif Aslam _ Darasal Full Video Song _ Raabta _ Su(MP3_160K)"];
let durations = ["04:24"];
let ipfsArray = [];

for (let i = 0; i < songs.length; i++) {
  ipfsArray.push({
    path: `metadata/${i}.json`,
    content: {
      image: `ipfs://QmVAXhjshTP92WtZDtqrsGtKKiN8dYJYAwibStt1GMSj4m/media/1'`, //xxx = hash
      name: songs[i],
      animation_url: `ipfs://QmVAXhjshTP92WtZDtqrsGtKKiN8dYJYAwibStt1GMSj4m/media/0'/`, //xxx = hash
      duration: durations[i],
      artist: "Atif Aslam",
      year: "2018"
    },
  });
}

axios.post("https://deep-index.moralis.io/api/v2/ipfs/uploadFolder", ipfsArray, {
  headers: {
    "X-API-KEY":
      "IS8Ur1KGjvLZpCQGMGb3IhOkuN8B8AjyPVoYXxfGI58UMp0iStee0AhTBedpKFLp",
    "Content-Type": "application/json",
    accept: "application/json",
  },
})
  .then((res) => {
    console.log(res.data);
  })
  .catch((error) => {
    console.log(error);
  });
